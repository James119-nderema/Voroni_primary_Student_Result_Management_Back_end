=======
AUTHORS
=======

..note: This document is outdated, please look at https://github.com/xhtml2pdf/xhtml2pdf/graphs/contributors

The following people contributed to xhtml2pdf in some fashion

Main developers
===============

* Dirk Holtwick (Main developer, no longer active)
* Christopher Glass (no longer active)
* Benjamin Bach (maintainer since '15)
* Luis Zárate Montero (maintainer since 2018)

Contributors
============

In no particular order. Names are taken from git logs, please contact
the maintainer should theses names be changed to something more relevant.

* Kenji Noguschi
* Pascal Bach
* peipei
* Vehbi Sinan Tunalioglu
* Nathan Duthoit
* Alan Justino
* David Tran
* Orestis Markou
* Yang Bo
* David Szotten
* Jim Thaxton
* Philippe Raoult
* Stefan Foulis
* Ethan Jucovy
* Marcus Weseloh
* Jacob Richardson
* Krzysztof Grodzicki
* Ted Liang
* fsx999
* Andrea Bravetti
* Dale O'Brien
* Bertrand Bordage
* "tomscytale"
* Nick Pack
* Jeff Tchang
* Andreas Stocker
* Dylan Jay
* mthornhill
* Andrea Bravetti
* Stéphane Bisinger
* Ling Thio
* Edwar Baron

Special thanks
==============

Dirk Holtwick, for opening the source to such a cool library :) Thanks!
Marcus Weseloh, for such a badass functional test suite.
